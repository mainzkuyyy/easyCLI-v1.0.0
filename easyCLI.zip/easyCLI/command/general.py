from .filesystem.system import *

def parse_flags(args):
    flags = set()
    while args and args[0].startswith("-") or args[0].startswith("--"):
        current_flag = args.pop(0)
        if current_flag.startswith("--"):
            flag_char = current_flag[2:]
            if len(flag_char) != 1:
                print(f"Error: '--{flag_char}' is invalid! Use 1 keyword (ex: --f)")
                continue
            flags.add(flag_char)
        else:
            for c in current_flag[1:]:
                flags.add(c)
    return flags, args

# General Command
def ls():
    all_file = " ".join(listDir())
    
    return print(all_file)
    
def cd(arg=None):
    if arg is None:
        return get_to_sandbox()
    
    return changeDir(arg)
    
def cp():
    return print(nowPosition())
    
def touch(arg):
    return createFile(arg)
    
def mkdir(arg):
    return createFolder(arg)
    
def mv(*arg):
    filename = arg[0]
    dst = arg[1]
    
    return moveFile(filename, dst)
    
def rm(*arg):
    arg = list(arg)
    
    if not arg:
        print("Missing operrand")
        return
        
    flags, targets = parse_flags(arg)
    
    if not targets:
        print("Missing file operrand")
        return
        
    for target in targets:
        deleteFile(target, flags)

def echo(*arg):
	print(" ".join(arg))