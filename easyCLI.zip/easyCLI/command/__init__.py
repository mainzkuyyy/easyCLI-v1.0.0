from .general import *

command_map = {
	"echo": echo,
	"ls": ls,
	"touch": touch,
	"rm": rm,
	"mkdir": mkdir,
	"cd": cd,
	"cp": cp,
	"mv": mv,
}