import os
import shutil

SANDBOX = os.path.abspath(".//sandbox")
CURRENT_DIR = SANDBOX

if not os.path.exists(SANDBOX):
    os.makedirs(SANDBOX, exist_ok=True)

os.chdir(os.path.dirname(SANDBOX))

def listDir():
    return os.listdir(CURRENT_DIR)

def get_to_sandbox():
    global CURRENT_DIR
    CURRENT_DIR = SANDBOX
    return CURRENT_DIR

def confirmation(message):
    print(message)
    
    try:
        answer = input("[y/N] ? \n")
    except EOFError as e:
        print(e)
        
    return answer in ("y", "Y", "yes")

def changeDir(dir):
    global CURRENT_DIR
    full_path = os.path.join(CURRENT_DIR, dir)
    
    if not full_path.startswith(SANDBOX):
        print("Access denied")
        return CURRENT_DIR
        
    if not os.path.exists(full_path):
        print("Directory not found")
        return
    
    if os.path.isdir(full_path):
        CURRENT_DIR = full_path
    
    return CURRENT_DIR
    
def nowPosition():
    rel = os.path.relpath(CURRENT_DIR, SANDBOX)
    return f"sandbox: {rel}"
    
def createFolder(foldername):
    full_path = os.path.join(CURRENT_DIR, foldername)
    
    if os.path.exists(full_path):
        print("Folder already exist")
        return
    
    try:
        os.makedirs(full_path, exist_ok=True)
        return full_path
    except OSError as e:
        print(f"Failed to create folder: {e}")
        return
        
    
def createFile(filename):
    full_path = os.path.join(CURRENT_DIR, filename)
    
    with open(full_path, "w") as f:
        f.write("Hello")
    
    return full_path
    
def deleteFile(filename, flags):
    full_path = os.path.realpath(os.path.normpath(os.path.join(CURRENT_DIR, filename)))
    
    if not os.path.commonpath([full_path, SANDBOX]) == SANDBOX:
        print("Access denied")
        return
        
    if not os.path.exists(full_path):
        print("File/folder not found")
        return
        
    if filename in (".", ".."):
        print("Refusing to remove '.' or '..'")
        return
            
    is_dir = os.path.isdir(full_path)
    
    need_confirm = False
    
    if "f" in flags:
        need_confirm = False
    elif "i" in flags:
        need_confirm = True
    elif is_dir:
        need_confirm = True
        
    if need_confirm:
        if not confirmation("This action will delete permanently, wanna do it? "):
            print("Aborted")
            return
            
    if is_dir:
        shutil.rmtree(full_path)
    else:
        os.remove(full_path)
    
def moveFile(filename, dir):
    fn_raw = os.path.join(CURRENT_DIR, filename)
    fn_norm = os.path.normpath(fn_raw)
    fn_real = os.path.realpath(fn_norm)
    
    dr_raw = os.path.join(CURRENT_DIR, dir)
    dr_norm = os.path.normpath(dr_raw)
    dr_real = os.path.realpath(dr_norm)
    
    if not os.path.commonpath([fn_real, SANDBOX]) == SANDBOX:
        print("File out of easyCLI prohibited limitation range")
        return
    
    if not os.path.commonpath([dr_real, SANDBOX]) == SANDBOX:
        print("Folder out of easyCLI prohibited limitation range")
        return
        
    if not os.path.exists(fn_real):
        print("File not found")
        return
        
    if not os.path.exists(dr_real):
        print("Folder not found")
        return
        
    if os.path.isdir(dr_real):
        final_target = os.path.join(dr_real, os.path.basename(fn_real))
    else:
        final_target = dr_real
        
    if fn_real == final_target:
        print("The destination are the same")
        return
    
    if os.path.exists(final_target):
        if not confirmation(f"File {os.path.basename(final_target)} is already exists, wanna overwrite? "):
            print("Aborted")
            return
        
    shutil.move(fn_real, final_target)