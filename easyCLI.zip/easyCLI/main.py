import sys
import os
from datetime import datetime
from command import command_map
from command.filesystem.system import nowPosition
from colorama import Back, Fore, Style

def now():
	ndate = datetime.now().strftime("%D")
	ntime = datetime.now().strftime("%H:%M")
	return ndate + " - " + ntime

def main():
	print("Powered By MainzKuyyy")
	print(Style.BRIGHT + Fore.YELLOW)
	print("easyCLI", Fore.WHITE, "|", Fore.RED, "Sandbox Aarch64 Linux for Mobile", Fore.WHITE)
	print("============================================")
	print("Datetime:", now(), "|")
	print("===========================|")
	print(f"Your CLI location path: {nowPosition()}")
	
	while True:
		try:
			user_input = input("$> ")
			if not user_input:
				continue
				
			parts = user_input.split()
			command = parts[0]
			arg = parts[1:]
			
			if command in command_map:
				command_map[command](*arg)
			else:
				print("No command in command map")
				
		except EOFError:
			sys.exit()
		except Exception as e:
			print(e)
			
if __name__ == "__main__":
	main()